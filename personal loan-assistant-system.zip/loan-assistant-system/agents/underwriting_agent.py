from models.state import LoanApplicationState

def underwriting_node(state: LoanApplicationState) -> LoanApplicationState:
    # Rule-based or LLM-driven underwriting check
    max_allowable_loan = state.income * 4.5
    if state.requested_amount <= max_allowable_loan:
        state.messages.append("Underwriting passed standard debt-to-income limits.")
        state.status = "RISK_ASSESSMENT"
    else:
        state.status = "REJECTED"
        state.messages.append("Underwriting failed: Requested amount exceeds max DTI ratio.")
    return state
