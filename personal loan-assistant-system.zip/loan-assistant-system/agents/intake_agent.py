from models.state import LoanApplicationState
from protocols.a2a import A2AEnvelope

def intake_node(state: LoanApplicationState) -> LoanApplicationState:
    # A2A Message Generation
    envelope = A2AEnvelope(
        sender_agent="IntakeAgent",
        recipient_agent="UnderwritingAgent",
        task_type="VALIDATE_APPLICANT",
        payload={"income": state.income, "requested_amount": state.requested_amount}
    )
    state.messages.append(f"[{envelope.timestamp}] Intake completed for application {state.application_id}")
    state.status = "DOC_REVIEW"
    return state
