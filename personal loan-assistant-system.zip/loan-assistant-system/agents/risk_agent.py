from models.state import LoanApplicationState

def risk_assessment_node(state: LoanApplicationState) -> LoanApplicationState:
    # Simulated Risk Scoring
    score = 720 if not state.credit_score else state.credit_score
    state.risk_score = float(score)
    if score >= 650:
        state.status = "APPROVED"
        state.messages.append(f"Risk Assessment passed with score {score}. Loan Approved.")
    else:
        state.status = "REJECTED"
        state.messages.append(f"Risk Assessment failed with score {score}. Loan Rejected.")
    return state
