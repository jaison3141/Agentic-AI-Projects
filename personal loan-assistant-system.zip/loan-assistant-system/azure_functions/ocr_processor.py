import azure.functions as func
import logging
import json

app = func.FunctionApp()

@app.blob_trigger(arg_name="file", path="loan-documents/{name}", connection="AzureWebJobsStorage")
def process_loan_document(file: func.InputStream):
    logging.info(f"Processing uploaded document: {file.name}, Size: {file.length} bytes")
    # Integration point with Azure AI Document Intelligence for W-2 / Paystub parsing
    extracted_metadata = {
        "filename": file.name,
        "verified_income": 85000.0,
        "employer": "Contoso Corp"
    }
    logging.info(f"Extracted metadata: {json.dumps(extracted_metadata)}")
