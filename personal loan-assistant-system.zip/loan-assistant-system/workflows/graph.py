from langgraph.graph import StateGraph, END
from models.state import LoanApplicationState
from agents.intake_agent import intake_node
from agents.underwriting_agent import underwriting_node
from agents.risk_agent import risk_assessment_node

def create_loan_graph():
    workflow = StateGraph(LoanApplicationState)

    # Add Nodes
    workflow.add_node("intake", intake_node)
    workflow.add_node("underwrite", underwriting_node)
    workflow.add_node("risk", risk_assessment_node)

    # Define Conditional Routing Logic
    def route_after_intake(state: LoanApplicationState):
        if state.status == "REJECTED":
            return END
        return "underwrite"

    def route_after_underwrite(state: LoanApplicationState):
        if state.status == "REJECTED":
            return END
        return "risk"

    # Set Edges
    workflow.set_entry_point("intake")
    workflow.add_conditional_edges("intake", route_after_intake)
    workflow.add_conditional_edges("underwrite", route_after_underwrite)
    workflow.add_edge("risk", END)

    return workflow.compile()
