import uuid
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uvicorn
from models.state import LoanApplicationState
from workflows.graph import create_loan_graph

app = FastAPI(title="Agentic AI Personal Loan Assistant API", version="1.0.0")
loan_graph = create_loan_graph()

class LoanRequestPayload(BaseModel):
    borrower_id: str
    requested_amount: float
    income: float
    credit_score: int

@app.post("/api/v1/loan/apply")
async def submit_loan_application(payload: LoanRequestPayload):
    try:
        app_id = f"APP-{uuid.uuid4().hex[:8].upper()}"
        initial_state = LoanApplicationState(
            application_id=app_id,
            borrower_id=payload.borrower_id,
            requested_amount=payload.requested_amount,
            income=payload.income,
            credit_score=payload.credit_score
        )
        
        # Execute LangGraph workflow
        final_state = loan_graph.invoke(initial_state)
        
        return {
            "status": "SUCCESS",
            "application_id": final_state["application_id"],
            "decision": final_state["status"],
            "risk_score": final_state.get("risk_score"),
            "audit_trail": final_state["messages"]
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
