import uuid
from datetime import datetime
from typing import Dict, Any, Optional
from pydantic import BaseModel, Field

class A2AEnvelope(BaseModel):
    trace_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    sender_agent: str
    recipient_agent: str
    timestamp: str = Field(default_factory=lambda: datetime.utcnow().isoformat())
    task_type: str
    payload: Dict[str, Any]
    security_token: Optional[str] = None
