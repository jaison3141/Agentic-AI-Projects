from typing import Dict, List, Optional, Any
from pydantic import BaseModel, Field

class LoanApplicationState(BaseModel):
    application_id: str
    borrower_id: str
    requested_amount: float
    income: float
    credit_score: Optional[int] = None
    documents: List[str] = Field(default_factory=list)
    extracted_data: Dict[str, Any] = Field(default_factory=dict)
    risk_score: Optional[float] = None
    status: str = "INTAKE"  # INTAKE, DOC_REVIEW, UNDERWRITING, APPROVED, REJECTED
    messages: List[str] = Field(default_factory=list)
